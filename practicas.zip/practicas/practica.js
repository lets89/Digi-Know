let img = document.createElement("img");
img.src = "Ingles.png";
img.alt = "imgen dinamica";
document.getElementById("contenido").appendChild(img);