function cambiarTitulo() {
  const titulo = document.getElementById("titulo");
  titulo.innerText = "¡Miau! Descubre el mundo de los gatitos";
}
